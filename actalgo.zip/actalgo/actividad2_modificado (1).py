import streamlit as st
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from io import BytesIO
import plotly.express as px
import matplotlib.pyplot as plt

st.set_page_config(page_title="K-Means con PCA y Comparativa", layout="wide")
st.title("Clustering Interactivo con K-Means y PCA (Comparación Antes/Después)")
st.write("""
Sube tus datos, aplica **K-Means** y observa cómo el algoritmo agrupa los puntos en un espacio reducido con **PCA (2D o 3D)**.  
También puedes comparar la distribución **antes y después** del clustering.
""")

# --- Subir archivo ---
st.sidebar.header("Subir datos")
uploaded_file = st.sidebar.file_uploader("Selecciona tu archivo CSV", type=["csv"])

if uploaded_file is not None:
    try:
        data = pd.read_csv(uploaded_file)
    except Exception as e:
        st.error(f"No se pudo leer el CSV: {e}")
        st.stop()

    st.success("Archivo cargado correctamente.")
    st.write("### Vista previa de los datos:")
    st.dataframe(data.head())

    # Filtrar columnas numéricas
    numeric_cols = data.select_dtypes(include=['number']).columns.tolist()

    if len(numeric_cols) < 2:
        st.warning("El archivo debe contener al menos dos columnas numéricas.")
    else:
        st.sidebar.header("Configuración del modelo")

        # Seleccionar columnas a usar
        selected_cols = st.sidebar.multiselect(
            "Selecciona las columnas numéricas para el clustering:",
            numeric_cols,
            default=numeric_cols
        )

        if len(selected_cols) < 2:
            st.warning("Selecciona al menos dos columnas numéricas para continuar.")
        else:
            # Limitar opciones de componentes PCA según número de características
            pca_options = [2]
            if len(selected_cols) >= 3:
                pca_options.append(3)

            # Parámetros de clustering
            k = st.sidebar.slider("Número de clusters (k):", 1, 10, 3)
            n_components = st.sidebar.radio("Visualización PCA:", pca_options, index=0)

            # --- Datos y modelo ---
            X = data[selected_cols].copy()

            try:
                kmeans = KMeans(n_clusters=k, init='k-means++', max_iter=300, n_init=10, random_state=42)
                kmeans.fit(X)
                data['Cluster'] = kmeans.labels_
            except Exception as e:
                st.error(f"Error al ajustar K-Means: {e}")
                st.stop()

            # --- PCA ---
            try:
                pca = PCA(n_components=n_components)
                X_pca = pca.fit_transform(X)
            except Exception as e:
                st.error(f"Error al aplicar PCA: {e}")
                st.stop()

            pca_cols = [f'PCA{i+1}' for i in range(n_components)]
            pca_df = pd.DataFrame(X_pca, columns=pca_cols)
            pca_df['Cluster'] = data['Cluster'].astype(str)

            # --- Visualización antes del clustering (sin colorear por cluster) ---
            st.subheader("Distribución original (antes de K-Means)")
            if n_components == 2:
                fig_before = px.scatter(
                    pca_df,
                    x='PCA1',
                    y='PCA2',
                    title="Datos originales proyectados con PCA (sin agrupar)",
                    color_discrete_sequence=["gray"],
                    hover_data=selected_cols
                )
            else:
                fig_before = px.scatter_3d(
                    pca_df,
                    x='PCA1',
                    y='PCA2',
                    z='PCA3',
                    title="Datos originales proyectados con PCA (sin agrupar)",
                    color_discrete_sequence=["gray"],
                    hover_data=selected_cols
                )
            st.plotly_chart(fig_before, use_container_width=True)

            # --- Visualización después del clustering ---
            st.subheader(f"Datos agrupados con K-Means (k = {k})")
            if n_components == 2:
                fig_after = px.scatter(
                    pca_df,
                    x='PCA1',
                    y='PCA2',
                    color='Cluster',
                    title="Clusters visualizados en 2D con PCA",
                    color_discrete_sequence=px.colors.qualitative.Vivid,
                    hover_data=selected_cols
                )
            else:
                fig_after = px.scatter_3d(
                    pca_df,
                    x='PCA1',
                    y='PCA2',
                    z='PCA3',
                    color='Cluster',
                    title="Clusters visualizados en 3D con PCA",
                    color_discrete_sequence=px.colors.qualitative.Vivid,
                    hover_data=selected_cols
                )
            st.plotly_chart(fig_after, use_container_width=True)

            # --- Centroides ---
            st.subheader("Centroides de los clusters (en espacio PCA)")
            try:
                centroides_pca = pd.DataFrame(pca.transform(kmeans.cluster_centers_), columns=pca_cols)
                centroides_pca['Cluster'] = [str(i) for i in range(len(centroides_pca))]
                st.dataframe(centroides_pca)
            except Exception as e:
                st.error(f"No se pudieron calcular los centroides en PCA: {e}")

            # --- Método del Codo ---
            st.subheader("Método del Codo (Elbow Method)")
            if st.button("Calcular número óptimo de clusters"):
                inertias = []
                K = range(1, 11)
                for i in K:
                    km = KMeans(n_clusters=i, random_state=42, n_init=10)
                    km.fit(X)
                    inertias.append(km.inertia_)

                fig2, ax2 = plt.subplots(figsize=(8, 6))
                ax2.plot(list(K), inertias, 'bo-')
                ax2.set_title('Método del Codo')
                ax2.set_xlabel('Número de Clusters (k)')
                ax2.set_ylabel('Inercia (SSE)')
                ax2.grid(True)
                st.pyplot(fig2)
                plt.close(fig2)

            # --- Descarga de resultados ---
            st.subheader("Descargar datos con clusters asignados")
            buffer = BytesIO()
            buffer.write(data.to_csv(index=False).encode('utf-8'))
            buffer.seek(0)
            st.download_button(
                label="Descargar CSV con Clusters",
                data=buffer.getvalue(),
                file_name="datos_clusterizados.csv",
                mime="text/csv"
            )

else:
    st.info("Carga un archivo CSV en la barra lateral para comenzar.")
    st.write("""
    **Ejemplo de formato:**
    | Ingreso_Anual | Gasto_Tienda | Edad |
    |----------------|--------------|------|
    | 45000 | 350 | 28 |
    | 72000 | 680 | 35 |
    | 28000 | 210 | 22 |
    """)